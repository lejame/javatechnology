package lab6_1.lab6_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab61ApplicationTests {

	@Test
	void contextLoads() {
	}

}
