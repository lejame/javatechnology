package tdtu.edu.vn.lab8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
